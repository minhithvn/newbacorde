﻿namespace volexbarcode
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.chươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.canonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fujiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoTheoCaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmKiếmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thiếtLậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dâyChuyềnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sảnPhẩmCanonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sảnPhẩmFujiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chươngTrìnhToolStripMenuItem,
            this.báoCáoToolStripMenuItem,
            this.thiếtLậpToolStripMenuItem,
            this.giớiThiệuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(533, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // chươngTrìnhToolStripMenuItem
            // 
            this.chươngTrìnhToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.canonToolStripMenuItem,
            this.fujiToolStripMenuItem});
            this.chươngTrìnhToolStripMenuItem.Name = "chươngTrìnhToolStripMenuItem";
            this.chươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(90, 22);
            this.chươngTrìnhToolStripMenuItem.Text = "Chương trình";
            // 
            // canonToolStripMenuItem
            // 
            this.canonToolStripMenuItem.Name = "canonToolStripMenuItem";
            this.canonToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.canonToolStripMenuItem.Text = "Canon";
            this.canonToolStripMenuItem.Click += new System.EventHandler(this.canonToolStripMenuItem_Click);
            // 
            // fujiToolStripMenuItem
            // 
            this.fujiToolStripMenuItem.Name = "fujiToolStripMenuItem";
            this.fujiToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.fujiToolStripMenuItem.Text = "Fuji";
            this.fujiToolStripMenuItem.Click += new System.EventHandler(this.fujiToolStripMenuItem_Click);
            // 
            // báoCáoToolStripMenuItem
            // 
            this.báoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.báoCáoTheoCaToolStripMenuItem,
            this.tìmKiếmToolStripMenuItem});
            this.báoCáoToolStripMenuItem.Name = "báoCáoToolStripMenuItem";
            this.báoCáoToolStripMenuItem.Size = new System.Drawing.Size(61, 22);
            this.báoCáoToolStripMenuItem.Text = "Báo cáo";
            // 
            // báoCáoTheoCaToolStripMenuItem
            // 
            this.báoCáoTheoCaToolStripMenuItem.Name = "báoCáoTheoCaToolStripMenuItem";
            this.báoCáoTheoCaToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.báoCáoTheoCaToolStripMenuItem.Text = "Báo cáo theo ca";
            this.báoCáoTheoCaToolStripMenuItem.Click += new System.EventHandler(this.báoCáoTheoCaToolStripMenuItem_Click);
            // 
            // tìmKiếmToolStripMenuItem
            // 
            this.tìmKiếmToolStripMenuItem.Name = "tìmKiếmToolStripMenuItem";
            this.tìmKiếmToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.tìmKiếmToolStripMenuItem.Text = "Tìm kiếm";
            this.tìmKiếmToolStripMenuItem.Click += new System.EventHandler(this.tìmKiếmToolStripMenuItem_Click);
            // 
            // thiếtLậpToolStripMenuItem
            // 
            this.thiếtLậpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dâyChuyềnToolStripMenuItem,
            this.sảnPhẩmCanonToolStripMenuItem,
            this.sảnPhẩmFujiToolStripMenuItem});
            this.thiếtLậpToolStripMenuItem.Name = "thiếtLậpToolStripMenuItem";
            this.thiếtLậpToolStripMenuItem.Size = new System.Drawing.Size(64, 22);
            this.thiếtLậpToolStripMenuItem.Text = "Thiết lập";
            // 
            // dâyChuyềnToolStripMenuItem
            // 
            this.dâyChuyềnToolStripMenuItem.Name = "dâyChuyềnToolStripMenuItem";
            this.dâyChuyềnToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.dâyChuyềnToolStripMenuItem.Text = "Dây chuyền";
            this.dâyChuyềnToolStripMenuItem.Click += new System.EventHandler(this.dâyChuyềnToolStripMenuItem_Click);
            // 
            // sảnPhẩmCanonToolStripMenuItem
            // 
            this.sảnPhẩmCanonToolStripMenuItem.Name = "sảnPhẩmCanonToolStripMenuItem";
            this.sảnPhẩmCanonToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.sảnPhẩmCanonToolStripMenuItem.Text = "Sản phẩm Canon";
            this.sảnPhẩmCanonToolStripMenuItem.Click += new System.EventHandler(this.sảnPhẩmCanonToolStripMenuItem_Click);
            // 
            // sảnPhẩmFujiToolStripMenuItem
            // 
            this.sảnPhẩmFujiToolStripMenuItem.Name = "sảnPhẩmFujiToolStripMenuItem";
            this.sảnPhẩmFujiToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.sảnPhẩmFujiToolStripMenuItem.Text = "Sản phẩm Fuji";
            this.sảnPhẩmFujiToolStripMenuItem.Click += new System.EventHandler(this.sảnPhẩmFujiToolStripMenuItem_Click);
            // 
            // giớiThiệuToolStripMenuItem
            // 
            this.giớiThiệuToolStripMenuItem.Name = "giớiThiệuToolStripMenuItem";
            this.giớiThiệuToolStripMenuItem.Size = new System.Drawing.Size(70, 22);
            this.giớiThiệuToolStripMenuItem.Text = "Giới thiệu";
            this.giớiThiệuToolStripMenuItem.Click += new System.EventHandler(this.giớiThiệuToolStripMenuItem_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmMain";
            this.Text = "Volex Barcode System";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem chươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem canonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fujiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoTheoCaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmKiếmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thiếtLậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dâyChuyềnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sảnPhẩmCanonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sảnPhẩmFujiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuToolStripMenuItem;
    }
}

